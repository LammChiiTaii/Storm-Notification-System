#ifndef INC_ERA_ESP8266_WIZ_HPP_
#define INC_ERA_ESP8266_WIZ_HPP_

#define ERA_MODBUS

#include <ERaSimpleEsp8266Wiz.hpp>

#endif /* INC_ERA_ESP8266_WIZ_HPP_ */
