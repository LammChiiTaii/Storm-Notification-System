#ifndef INC_ERA_TASK_HPP_
#define INC_ERA_TASK_HPP_

#include <stdint.h>
#include <ERa/ERaDefine.hpp>

#define RUN_ERA_TASK() void runERaLoopTask(void ERA_UNUSED *args)

RUN_ERA_TASK();

#endif /* INC_ERA_TASK_HPP_ */
