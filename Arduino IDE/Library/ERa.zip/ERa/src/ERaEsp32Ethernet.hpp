#ifndef INC_ERA_ESP32_ETHERNET_HPP_
#define INC_ERA_ESP32_ETHERNET_HPP_

#define ERA_MODBUS
#define ERA_ZIGBEE

#include <ERaSimpleEsp32Ethernet.hpp>

#endif /* INC_ERA_ESP32_ETHERNET_HPP_ */
