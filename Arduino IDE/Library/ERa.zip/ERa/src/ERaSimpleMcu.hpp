#ifndef INC_ERA_SIMPLE_MCU_HPP_
#define INC_ERA_SIMPLE_MCU_HPP_

#include <MCU/ERaMcu.hpp>

#endif /* INC_ERA_SIMPLE_MCU_HPP_ */
